var md5 = require('blueimp-md5')
console.log(md5('admin'))